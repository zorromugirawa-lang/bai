export const handle = async ({ event, resolve }) => {
  // Get language from URL or other server logic
  let lang = event.url.pathname.split('/')[1] || 'en';
  
  // Check if lang is not a 2-letter code, if so set it to 'en'
  if (!lang || lang.length !== 2) {
      lang = 'en';
  }
  
  // Store language in event.locals for use in load functions
  event.locals.lang = lang;
  
  // Transform the HTML to include the lang attribute
  return await resolve(event, {
    transformPageChunk: ({ html, done }) => {
      if (done) {
        // Replace the %lang% placeholder with the lang value
        return html.replace('%lang%', lang);
      }
      return html;
    }
  });
};