<!-- AdvantagesSection.svelte -->
<script>
	export let translations;
</script>

<section class="container px-4 mx-auto my-12">
	<h2 class="mb-6 text-2xl font-bold text-center">{translations.title}</h2>

	<div class="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
		{#each translations.items as item}
			<div
				class="p-6 text-center transition-all duration-200 bg-white shadow rounded-lg card dark:bg-surface-800 hover:shadow-lg"
			>
				<div
					class="flex items-center justify-center w-12 h-12 mx-auto mb-4 rounded-full bg-primary-100 dark:bg-primary-900 text-primary-500"
				>
					<i class="fa-solid {item.icon} text-xl"></i>
				</div>
				<h3 class="mb-2 text-lg font-semibold">{item.title}</h3>
				<p class="text-surface-600-300-token">{item.description}</p>
			</div>
		{/each}
	</div>
</section>
