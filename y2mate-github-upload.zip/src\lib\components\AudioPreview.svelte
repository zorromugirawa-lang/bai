<script>
	export let audioUrl = '';
	export let title = '';

	import { onMount, onDestroy } from 'svelte';

	let audio;
	let isPlaying = false;
	let currentTime = 0;
	let duration = 0;
	let progress = 0;

	onMount(() => {
		if (audio) {
			audio.addEventListener('timeupdate', updateProgress);
			audio.addEventListener('loadedmetadata', () => {
				duration = audio.duration;
			});
			audio.addEventListener('ended', () => {
				isPlaying = false;
			});
		}
	});

	onDestroy(() => {
		if (audio) {
			audio.removeEventListener('timeupdate', updateProgress);
			audio.pause();
		}
	});

	function updateProgress() {
		currentTime = audio.currentTime;
		progress = (currentTime / duration) * 100;
	}

	function togglePlay() {
		if (isPlaying) {
			audio.pause();
		} else {
			audio.play();
		}
		isPlaying = !isPlaying;
	}

	function formatTime(seconds) {
		if (isNaN(seconds)) return '0:00';
		const mins = Math.floor(seconds / 60);
		const secs = Math.floor(seconds % 60)
			.toString()
			.padStart(2, '0');
		return `${mins}:${secs}`;
	}

	function seek(e) {
		const rect = e.currentTarget.getBoundingClientRect();
		const percent = (e.clientX - rect.left) / rect.width;
		audio.currentTime = percent * duration;
	}
</script>

{#if audioUrl}
	<div class="p-4 bg-white card dark:bg-surface-800">
		<h3 class="mb-3 font-semibold">Audio Preview</h3>

		<audio bind:this={audio} src={audioUrl} preload="metadata"></audio>

		<div class="flex items-center mb-2">
			<button class="mr-2 btn-icon btn-icon-sm variant-filled-primary" on:click={togglePlay}>
				<i class="fa-solid {isPlaying ? 'fa-pause' : 'fa-play'}"></i>
			</button>

			<div class="w-16 text-sm text-surface-600-300-token">
				{formatTime(currentTime)}
			</div>

			<div
				class="flex-1 h-2 rounded-full cursor-pointer progress bg-surface-300-600-token"
				on:click={seek}
			>
				<div
					class="h-full rounded-full progress-bar bg-primary-500"
					style="width: {progress}%"
				></div>
			</div>

			<div class="w-16 text-sm text-right text-surface-600-300-token">
				{formatTime(duration)}
			</div>
		</div>

		<p class="mt-2 text-sm text-center text-surface-600-300-token">
			Preview of "{title}" - Download to get the full audio
		</p>
	</div>
{/if}
