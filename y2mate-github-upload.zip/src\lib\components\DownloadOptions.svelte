<script>
	import AudioPreview from './AudioPreview.svelte';
	import { slide } from 'svelte/transition';
	import { quintOut } from 'svelte/easing';

	export let downloadOptions = { audio: [], video: [] };
	export let title = '';

	// For preview, we'll use the lowest quality audio to save bandwidth
	$: previewAudioUrl =
		downloadOptions.audio.length > 0
			? downloadOptions.audio[downloadOptions.audio.length - 1].url
			: '';

	// Track which download option is currently active
	let activeDownloadFrame = null;
	let showActiveFrame = false;
	let showNotification = false;
	let notificationTimeout;

	// Function to handle download button clicks
	function handleDownloadClick(url, quality, type) {
		// If an iframe is already showing, display notification instead of changing iframe
		if (showActiveFrame && activeDownloadFrame) {
			showNotification = true;

			// Clear any existing timeout
			if (notificationTimeout) {
				clearTimeout(notificationTimeout);
			}

			// Auto-hide notification after 3 seconds
			notificationTimeout = setTimeout(() => {
				showNotification = false;
			}, 3000);

			return;
		}

		// Set the active download URL and toggle visibility
		const frameId = `${type}-${quality}`;
		activeDownloadFrame = frameId;
		showActiveFrame = true;
	}

	// This function is not used anymore as we don't want to allow closing the frame
	// Keeping it commented out in case we need to restore it later
	/*
  function closeDownloadFrame() {
    showActiveFrame = false;
    setTimeout(() => {
      activeDownloadFrame = null;
    }, 300); // Wait for transition to complete
  }
  */
</script>

<div class="w-full">
	<!-- {#if previewAudioUrl}
  <AudioPreview audioUrl={previewAudioUrl} {title} />
  <div class="my-4 divider"></div>
{/if} -->

	<!-- Notification message -->
	<!-- {#if showNotification}
  <div transition:slide={{ duration: 300, easing: quintOut }} 
       class="p-2 mb-3 text-center rounded-lg bg-warning-500/20 text-warning-700 dark:text-warning-300">
    <p class="text-sm font-medium">Please generate video again</p>
  </div>
{/if} -->

	<!-- Only show audio section when no iframe is active -->
	{#if !showActiveFrame}
	<div class="mb-8">
		<h4 class="flex items-center mb-4 font-semibold">
			<i class="mr-2 fa-solid fa-music text-primary-500"></i>
			Download Audio
		</h4>
		<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
			{#each downloadOptions.audio as option}
				<button
					class="text-center transition-all btn variant-soft-primary hover:variant-filled-primary"
					on:click={() => handleDownloadClick(option.url, option.quality, 'audio')}
				>
					<i class="fa-solid fa-download mr-2"></i>Download {option.quality} kbps
				</button>
			{/each}
		</div>
	</div>
	
	<div class="mb-8">
		<h4 class="flex items-center mb-4 font-semibold">
			<i class="mr-2 fa-solid fa-video text-tertiary-500"></i>
			Download Video
		</h4>
		<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
			{#each [...downloadOptions.video].reverse() as option}
				<button
					class="text-center transition-all btn variant-soft-secondary hover:variant-filled-secondary"
					on:click={() => handleDownloadClick(option.url, option.quality, 'video')}
				>
					<i class="fa-solid fa-download mr-2"></i>Download {option.quality}p
				</button>
			{/each}
		</div>
	</div>
	{/if}

	<!-- Audio Download Frame -->
	{#if showActiveFrame && activeDownloadFrame && activeDownloadFrame.startsWith('audio')}
		<div
			transition:slide={{ duration: 300, easing: quintOut }}
			class="p-4 mt-3 rounded-lg bg-surface-500"
		>
			<div class="flex items-center justify-between mb-2">
				<p class="text-sm text-white font-medium">
					Downloading {activeDownloadFrame.split('-')[1]} kbps audio
				</p>
			</div>

			<iframe
				src={downloadOptions.audio.find((o) => o.quality === activeDownloadFrame.split('-')[1])
					?.url}
				title="Download {activeDownloadFrame.split('-')[1]} kbps audio"
				class="w-full h-[500px] border-0"
			></iframe>

			<!-- <p class="mt-2 text-xs text-center text-surface-600-300-token">
      If download doesn't start automatically, 
      <a 
        href={downloadOptions.audio.find(o => o.quality === activeDownloadFrame.split('-')[1])?.url} 
        class="text-primary-500 hover:underline"
        download
      >
        click here
      </a>
    </p> -->
		</div>
	{/if}

	<!-- Video Download Frame -->
	{#if showActiveFrame && activeDownloadFrame && activeDownloadFrame.startsWith('video')}
		<div
			transition:slide={{ duration: 300, easing: quintOut }}
			class="p-2 mt-3 rounded-lg bg-surface-500"
		>
			<div class="flex items-center justify-between mb-2">
				<p class="text-sm text-white font-medium">Downloading {activeDownloadFrame.split('-')[1]}p video</p>
			</div>

			<iframe
				src={downloadOptions.video.find((o) => o.quality === activeDownloadFrame.split('-')[1])
					?.url}
				title="Download {activeDownloadFrame.split('-')[1]}p video"
				class="w-full h-[500px] border-0"
			></iframe>

			<!-- <p class="mt-2 text-xs text-center text-surface-600-300-token">
				If download doesn't start automatically,
				<a
					href={downloadOptions.video.find((o) => o.quality === activeDownloadFrame.split('-')[1])
						?.url}
					class="text-primary-500 hover:underline"
					download
				>
					click here
				</a>
			</p> -->
		</div>
	{/if}
</div>
