<script>
	export let translations;
</script>

<section class="container px-6 mx-auto my-16">
	<h2
		class="mb-8 text-3xl font-bold text-center text-transparent bg-gradient-to-r from-primary-500 to-purple-600 bg-clip-text"
	>
		{translations.sectionTitle}
	</h2>

	<div class="grid grid-cols-1 gap-8 md:grid-cols-3">
		{#each translations.featured as feature, i}
			<div
				class="p-8 text-center transition-all duration-300 bg-white shadow-lg card dark:bg-gray-800 rounded-xl hover:shadow-xl hover:-translate-y-1"
			>
				<div
					class="mb-6 mx-auto w-16 h-16 flex items-center justify-center bg-{feature.colorClass}-100 dark:bg-{feature.colorClass}-900 text-{feature.colorClass}-600 dark:text-{feature.colorClass}-300 rounded-full"
				>
					<i class="fa-solid {feature.icon} text-2xl"></i>
				</div>
				<h3 class="mb-3 text-xl font-semibold">{feature.title}</h3>
				<p class="text-gray-600 dark:text-gray-300">{feature.description}</p>
			</div>
		{/each}
	</div>
</section>
