<script>
	import { formatDuration } from '$lib/utils/api.js';
	import DownloadOptions from './DownloadOptions.svelte';
	import VideoPreview from './VideoPreview.svelte';
	import VideoMetadata from './VideoMetadata.svelte';

	export let videoInfo = null;

	let showDownloadOptions = true;

	function toggleDownloadOptions() {
		showDownloadOptions = !showDownloadOptions;
	}

	$: videoId = videoInfo?.data?.id || '';
	$: title = videoInfo?.data?.title || '';
</script>

{#if videoInfo}
	<div class="space-y-4">
		<VideoPreview {videoInfo} />

		<div class="p-4 overflow-hidden bg-white shadow-lg card dark:bg-surface-800">
			<button class="w-full text-xs rounded-4xl btn variant-filled-primary flex items-center gap-2 justify-center font-semibold" on:click={toggleDownloadOptions}>
				<div>
					<i class="fa-solid fa-arrow-down"></i>
					<i class="fa-solid fa-arrow-down"></i>
				</div>
				<span>DOWNLOAD LINK</span>
				<div>
					<i class="fa-solid fa-arrow-down"></i>
					<i class="fa-solid fa-arrow-down"></i>

				</div>

			  </button>

			{#if showDownloadOptions}
				<div class="mt-6">
					<DownloadOptions downloadOptions={videoInfo.download_url} {title} />
				</div>
			{/if}
		</div>

		<VideoMetadata {videoInfo} />
	</div>
{/if}
