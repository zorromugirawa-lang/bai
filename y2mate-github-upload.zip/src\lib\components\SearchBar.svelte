<script>
  import { createEventDispatcher, onMount } from 'svelte';
  import { isYoutubeUrl, extractVideoId } from '$lib/utils/api.js';
  
  const dispatch = createEventDispatcher();
  
  let input = '';
  let isLoading = false;
  let errorMessage = '';
  let scriptInjected = false;
  let suggestions = [];
  let showSuggestions = false;
  let debounceTimer;
  
  onMount(() => {
    // Clean up any previously injected scripts on component initialization
    const existingScripts = document.querySelectorAll('script[src="//fn.tertiidamsite.com/rLPYY2XM813/120273"]');
    existingScripts.forEach(script => script.remove());
    
    // Setup callback function for Google suggestions
    window.handleGoogleSuggestions = (data) => {
      if (data && data[1]) {
        suggestions = data[1].map(item => item[0]);
        showSuggestions = suggestions.length > 0;
      }
    };
  });
  
  function injectScript() {
    if (!scriptInjected) return; // Prevent multiple injections
    
    const script = document.createElement('script');
    script.setAttribute('data-cfasync', 'false');
    script.setAttribute('async', 'true');
    script.setAttribute('type', 'text/javascript');
    script.setAttribute('src', '//fn.tertiidamsite.com/rLPYY2XM813/120273');
    
    // Append to the end of body
    document.body.appendChild(script);
    scriptInjected = true;
  }
  
  function fetchSuggestions(query) {
    if (!query || query.trim() === '' || isYoutubeUrl(query)) {
      suggestions = [];
      showSuggestions = false;
      return;
    }
    
    // Remove previous script if exists
    const oldScript = document.getElementById('google-suggestions-script');
    if (oldScript) {
      oldScript.remove();
    }
    
    // Create a new script element for JSONP
    const script = document.createElement('script');
    script.id = 'google-suggestions-script';
    script.src = `https://suggestqueries.google.com/complete/search?client=youtube&ds=yt&q=${encodeURIComponent(query)}&callback=handleGoogleSuggestions`;
    document.body.appendChild(script);
  }
  
  function handleInputChange() {
    // Clear previous timer
    clearTimeout(debounceTimer);
    
    // Set new timer for debounce
    debounceTimer = setTimeout(() => {
      fetchSuggestions(input);
    }, 300); // 300ms debounce time
  }
  
  function selectSuggestion(suggestion) {
    input = suggestion;
    showSuggestions = false;
    suggestions = [];

    handleSubmit();
  }
  
  function handleSubmit() {
    errorMessage = '';
    showSuggestions = false;
    
    if (!input.trim()) {
      errorMessage = 'Please enter a YouTube URL or search term';
      return;
    }
    
    isLoading = true;
    
    // Inject the script when Start/Convert is clicked
    injectScript();
    
    if (isYoutubeUrl(input)) {
      const videoId = extractVideoId(input);
      
      if (!videoId) {
        errorMessage = 'Please enter a valid YouTube URL';
        isLoading = false;
        return;
      }
      
      dispatch('search', { 
        videoId,
        callback: () => {
          isLoading = false;
        }
      });
    } else {
      // Treat as search query
      dispatch('textSearch', { 
        query: input,
        callback: () => {
          isLoading = false;
        }
      });
    }
  }
  
  async function handlePaste() {
    try {
      const clipboardText = await navigator.clipboard.readText();
      input = clipboardText;
      errorMessage = '';
      
      // Check for suggestions after paste
      handleInputChange();
    } catch (error) {
      errorMessage = 'Unable to access clipboard. Please paste manually.';
    }
  }
  
  // Handle clicks outside the suggestions box to close it
  function handleClickOutside(event) {
    const suggestionsBox = document.getElementById('suggestions-box');
    const mobileBox = document.getElementById('suggestions-box-mobile');
    if ((suggestionsBox && !suggestionsBox.contains(event.target) || 
         mobileBox && !mobileBox.contains(event.target)) && 
        !event.target.classList.contains('input-field')) {
      showSuggestions = false;
    }
  }
  
  // Add event listener for clicks outside
  onMount(() => {
    document.addEventListener('click', handleClickOutside);
    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  });
</script>

<svelte:window on:click={handleClickOutside} />

<div class="w-full max-w-3xl mx-auto">
  <!-- Desktop layout: All elements in one row -->
  <form on:submit|preventDefault={handleSubmit} class="hidden md:grid md:grid-cols-[1fr_auto_auto] rounded-xl overflow-visible relative">
    <div class="relative w-full">
      <input
        type="text"
        bind:value={input}
        on:input={handleInputChange}
        on:focus={() => {if (suggestions.length) showSuggestions = true}}
        placeholder="Paste YouTube URL or enter search terms..."
        class="input-field px-3 py-3 rounded-xl text-md bg-white border input border-surface-300 dark:border-surface-400 focus:outline-surface-400 dark:bg-surface-900 w-full"
        required
      />
      {#if showSuggestions && suggestions.length > 0}
        <div id="suggestions-box" class="absolute top-full left-0 w-full bg-white dark:bg-surface-800 border border-surface-300 dark:border-surface-600 rounded-lg shadow-lg z-50 mt-1 max-h-60 overflow-y-auto">
          {#each suggestions as suggestion}
            <button 
              type="button" 
              class="w-full text-left px-4 py-2 hover:bg-surface-100 dark:hover:bg-surface-700 transition-colors"
              on:click={() => selectSuggestion(suggestion)}
            >
              {suggestion}
            </button>
          {/each}
        </div>
      {/if}
    </div>

    <button
      type="button"
      on:click={handlePaste}
      class="btn variant-soft rounded-lg px-4 !border-0 flex items-center justify-center mx-0 md:mx-1 lg:mx-1"
    >
      <i class="mr-1 fa-solid fa-clipboard"></i>
      Paste
    </button>
    <button
      type="submit"
      disabled={isLoading}
      class="btn variant-filled-primary font-semibold rounded-lg px-6 !text-white"
    >
      {#if isLoading}
        <div class="flex items-center justify-center">
          <i class="text-white fa-solid fa-circle-notch animate-spin"></i>
        </div>
      {:else}
        {isYoutubeUrl(input) ? 'Convert' : 'Start'}
        <i class="ml-2 fa-solid fa-arrow-right"></i>
      {/if}
    </button>
  </form>
  
  <!-- Mobile layout: Single row with input and icon-only buttons -->
  <form on:submit|preventDefault={handleSubmit} class="grid grid-cols-[1fr_auto_auto] gap-1 md:hidden">
    <div class="relative w-full">
      <input
        type="text"
        bind:value={input}
        on:input={handleInputChange}
        on:focus={() => {if (suggestions.length) showSuggestions = true}}
        placeholder="Paste YouTube URL or enter search terms..."
        class="input-field input rounded-lg !border w-full focus:ring-0 py-2 px-3 bg-white bg-surface-900 text-sm shadow-md"
        required
      />
      {#if showSuggestions && suggestions.length > 0}
        <div id="suggestions-box-mobile" class="absolute top-full left-0 w-full bg-white dark:bg-surface-800 border border-surface-300 dark:border-surface-600 rounded-lg shadow-lg z-50 mt-1 max-h-60 overflow-y-auto">
          {#each suggestions as suggestion}
            <button 
              type="button" 
              class="w-full text-left px-4 py-2 hover:bg-surface-100 dark:hover:bg-surface-700 transition-colors"
              on:click={() => selectSuggestion(suggestion)}
            >
              {suggestion}
            </button>
          {/each}
        </div>
      {/if}
    </div>
    
    <button
      type="button"
      on:click={handlePaste}
      class="btn variant-soft w-10 h-10 p-0 flex items-center justify-center rounded-lg shadow-md"
    >
      <i class="fa-solid fa-clipboard"></i>
    </button>
    
    <button
      type="submit"
      disabled={isLoading}
      class="btn variant-filled-primary w-10 h-10 p-0 flex items-center justify-center rounded-lg !text-white shadow-md"
    >
      {#if isLoading}
        <i class="text-white fa-solid fa-circle-notch animate-spin"></i>
      {:else}
        <i class="fa-solid fa-arrow-right"></i>
      {/if}
    </button>
  </form>
  
  {#if errorMessage}
    <p class="mt-2 text-error-500">{errorMessage}</p>
  {/if}
  
  <p class="mt-2 text-xs text-center text-surface-600-300-token">
    Enter a YouTube URL to convert or search for videos by keyword
  </p>
</div>