<script>
	import { createEventDispatcher } from 'svelte';
	import { fade, slide } from 'svelte/transition';

	export let searchResults = { items: [], nextPage: null };
	export let isLoading = false;
	export let query = '';

	const dispatch = createEventDispatcher();

	let filterType = 'all'; // all, video, live

	function handleVideoSelect(videoId) {
		dispatch('selectVideo', { videoId });
	}

	function handleDownload(item, event) {
		event.stopPropagation(); // Prevent triggering the parent click event
		dispatch('downloadItem', { item });
	}

	function loadMore() {
		dispatch('loadMore');
	}

	function formatDuration(durationText) {
		if (!durationText) return 'LIVE';

		// Format duration for better display
		return durationText.replace(/\./g, ':');
	}

	function getItemIcon(item) {
		if (item.isLive) {
			return 'fa-solid fa-tower-broadcast';
		} else {
			return 'fa-solid fa-play';
		}
	}

	// Filtered results based on selected filter
	$: filteredResults = searchResults.items.filter((item) => {
		if (filterType === 'all') return true;
		if (filterType === 'video') return !item.isLive;
		if (filterType === 'live') return item.isLive;
		return true;
	});
</script>

<div class="w-full">
	{#if isLoading}
		<div class="flex flex-col items-center py-8" in:fade>
			<div class="w-12 h-12 spinner">
				<i class="text-3xl fa-solid fa-circle-notch animate-spin text-primary-500"></i>
			</div>
			<p class="mt-4 text-surface-600-300-token">Searching for "{query}"...</p>
		</div>
	{:else if searchResults.items && searchResults.items.length > 0}
		<div in:slide={{ duration: 300 }}>
			<div class="flex flex-col justify-between mb-4 sm:flex-row sm:items-center">
				<h3 class="text-xl font-semibold">Search Results for "{query}"</h3>

				<!-- <div class="flex items-center mt-2 sm:mt-0">
          <span class="mr-2 text-sm">Filter:</span>
          <div class="btn-group">
            <button 
              class="btn btn-sm {filterType === 'all' ? 'variant-filled-primary' : 'variant-soft'}"
              on:click={() => filterType = 'all'}
            >
              All
            </button>
            <button 
              class="btn btn-sm {filterType === 'video' ? 'variant-filled-primary' : 'variant-soft'}"
              on:click={() => filterType = 'video'}
            >
              Videos
            </button>
            <button 
              class="btn btn-sm {filterType === 'live' ? 'variant-filled-primary' : 'variant-soft'}"
              on:click={() => filterType = 'live'}
            >
              Live
            </button>
          </div>
        </div> -->
			</div>

			{#if filteredResults.length === 0}
				<div class="alert variant-ghost-warning" in:fade>
					<i class="mr-2 fa-solid fa-filter-circle-xmark"></i>
					No results match your current filter. Try a different filter option.
				</div>
			{:else}
				<div class="space-y-3">
					{#each filteredResults as item}
						<div
							class="flex items-center p-4 transition-all bg-white cursor-pointer card dark:bg-surface-800 hover:shadow-lg"
							on:click={() => handleVideoSelect(item.id)}
							in:fade={{ duration: 200, delay: 100 }}
						>
							<div
								class="flex items-center justify-center flex-shrink-0 w-10 h-10 mr-4 rounded-full bg-primary-100 dark:bg-primary-900"
							>
								<i class="{getItemIcon(item)} text-primary-500"></i>
							</div>

							<div class="flex-grow min-w-0">
								<h4 class="text-md font-medium truncate">{item.title}</h4>
								<p class="flex items-center text-sm text-surface-600-300-token">
									<i class="mr-1 text-xs fa-solid fa-user"></i>
									<span class="truncate">{item.channelTitle}</span>

									{#if item.length}
										<span class="mx-2">•</span>
										<i class="mr-1 text-xs fa-regular fa-clock"></i>
										{formatDuration(item.length.simpleText)}
									{:else if item.isLive}
										<span class="mx-2">•</span>
										<span class="flex items-center text-red-500">
											<i class="mr-1 text-xs fa-solid fa-circle"></i> LIVE
										</span>
									{/if}
								</p>
							</div>

							<div class="flex-shrink-0 ml-2">
								<button
									class="btn btn-sm variant-soft"
									on:click={(event) => handleDownload(item, event)}
									title="Download"
								>
									<i class="fa-solid fa-download"></i>
								</button>
							</div>
						</div>
					{/each}
				</div>

				{#if searchResults.nextPage}
					<div class="flex justify-center mt-6">
						<button class="btn variant-soft-primary" on:click={loadMore}>
							<i class="mr-2 fa-solid fa-chevron-down"></i>
							Load More Results
						</button>
					</div>
				{/if}
			{/if}
		</div>
	{:else}
		<div class="alert variant-ghost-warning" in:fade>
			<i class="mr-2 fa-solid fa-exclamation-triangle"></i>
			No results found for "{query}". Try a different search term.
		</div>
	{/if}
</div>
