<script>
	export let videoId = '';
	export let title = '';

	function copyToClipboard() {
		const url = window.location.origin + '?v=' + videoId;
		navigator.clipboard
			.writeText(url)
			.then(() => {
				toast.push({
					message: 'URL copied to clipboard!',
					background: 'variant-filled-success'
				});
			})
			.catch((err) => {
				console.error('Failed to copy URL: ', err);
				toast.push({
					message: 'Failed to copy URL',
					background: 'variant-filled-error'
				});
			});
	}

	function shareOnTwitter() {
		const text = `Converting "${title}" with this awesome YouTube to MP3 converter!`;
		const url = window.location.origin + '?v=' + videoId;
		window.open(
			`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`,
			'_blank'
		);
	}

	function shareOnFacebook() {
		const url = window.location.origin + '?v=' + videoId;
		window.open(
			`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`,
			'_blank'
		);
	}

	function shareOnWhatsapp() {
		const text = `Check out this YouTube to MP3 converter I'm using for "${title}": `;
		const url = window.location.origin + '?v=' + videoId;
		window.open(`https://wa.me/?text=${encodeURIComponent(text + url)}`, '_blank');
	}

	import { toast } from '@skeletonlabs/skeleton';
</script>

<div class="p-4 bg-white card dark:bg-surface-800">
	<h3 class="mb-3 font-semibold">Share This Converter</h3>

	<div class="grid grid-cols-2 gap-2 sm:grid-cols-4">
		<button class="btn variant-soft" on:click={copyToClipboard}>
			<i class="mr-2 fa-solid fa-copy"></i>
			Copy URL
		</button>

		<button class="btn variant-soft-secondary" on:click={shareOnTwitter}>
			<i class="mr-2 fa-brands fa-twitter"></i>
			Twitter
		</button>

		<button class="btn variant-soft-primary" on:click={shareOnFacebook}>
			<i class="mr-2 fa-brands fa-facebook"></i>
			Facebook
		</button>

		<button class="btn variant-soft-success" on:click={shareOnWhatsapp}>
			<i class="mr-2 fa-brands fa-whatsapp"></i>
			WhatsApp
		</button>
	</div>
</div>
