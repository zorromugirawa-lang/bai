<script>
	import { getContext } from 'svelte';

	const themes = ['skeleton', 'modern', 'crimson'];
	let currentTheme = 'crimson';

	function setTheme(theme) {
		document.body.setAttribute('data-theme', theme);
		currentTheme = theme;
		localStorage.setItem('preferred-theme', theme);
	}

	// Initialize theme from localStorage on mount
	import { onMount } from 'svelte';
	onMount(() => {
		const savedTheme = localStorage.getItem('preferred-theme') || 'crimson';
		setTheme(savedTheme);
	});
</script>

<div class="dropdown">
	<button class="btn btn-sm variant-ghost-primary">
		<i class="mr-1 fa-solid fa-palette"></i>
		Theme
		<i class="ml-1 fa-solid fa-caret-down"></i>
	</button>
	<div class="dropdown-menu">
		{#each themes as theme}
			<button
				class="dropdown-item {currentTheme === theme ? 'variant-soft-primary' : ''}"
				on:click={() => setTheme(theme)}
			>
				{theme.charAt(0).toUpperCase() + theme.slice(1)}
			</button>
		{/each}
	</div>
</div>
