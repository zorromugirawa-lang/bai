<script>
	export let videoInfo;
	let expanded = false;

</script>

{#if videoInfo && videoInfo.data}
	<div class="p-4 bg-white card dark:bg-surface-800">
		<h3 class="mb-3 font-semibold">Video Information</h3>

		<div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
			<div>
				<p class="text-sm text-surface-600-300-token">Channel</p>
				<p class="font-medium">
					<a
						href={videoInfo.data.channel.url}
						target="_blank"
						rel="noopener noreferrer"
						class="text-primary-500 hover:underline"
					>
						{videoInfo.data.channel.name}
					</a>
				</p>
			</div>

			<!-- <div>
				<p class="text-sm text-surface-600-300-token">Category</p>
				<p class="font-medium">{videoInfo.data.category}</p>
			</div>

			<div>
				<p class="text-sm text-surface-600-300-token">Duration</p>
				<p class="font-medium">{videoInfo.data.duration}</p>
			</div> -->

			<div>
				<p class="text-sm text-surface-600-300-token">Likes</p>
				<p class="flex items-center font-medium">
					{videoInfo.data.like_count?.toLocaleString()
						? videoInfo.data.like_count?.toLocaleString()
						: '-'}
					<i class="ml-2 fa-solid fa-thumbs-up text-tertiary-500"></i>
				</p>
			</div>
		</div>

		{#if videoInfo.data.short_description}
			<div class="mt-4">
				<p class="mb-1 text-sm text-surface-600-300-token">Description</p>
				<div class="description-container max-w-full overflow-hidden">
				  {#if expanded}
					{#each videoInfo.data.short_description.split('\n') as line}
					  <p class="text-sm break-words">{line}</p>
					{/each}
				  {:else}
					<p class="text-sm line-clamp-3 break-words">{videoInfo.data.short_description}</p>
				  {/if}				  
				</div>				
				<button 
				class="mt-2 btn btn-sm variant-ghost-primary"
				on:click={() => expanded = !expanded}
				>
				{expanded ? 'Show Less' : 'Read More'}
				</button>
			</div>
		{/if}
	</div>
{/if}
