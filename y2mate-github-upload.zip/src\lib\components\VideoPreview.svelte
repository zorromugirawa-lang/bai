<script>
	export let videoInfo;
	import { formatDuration } from '$lib/utils/api';

	let showEmbed = false;

	function toggleEmbed() {
		showEmbed = !showEmbed;
	}
</script>

{#if videoInfo && videoInfo.data}
	<div class="mb-4 overflow-hidden bg-white card dark:bg-surface-800">
		{#if !showEmbed}
			<div class="relative cursor-pointer" on:click={toggleEmbed}>
				<img
					src={videoInfo.data.thumbnail[0].url}
					alt={videoInfo.data.title}
					class="w-full h-auto"
				/>
				<div class="absolute inset-0 flex items-center justify-center bg-black bg-opacity-40">
					<div
						class="flex items-center justify-center w-16 h-16 text-white rounded-full bg-primary-500"
					>
						<i class="text-2xl fa-solid fa-play"></i>
					</div>
				</div>
				<div
					class="absolute px-2 py-1 text-sm text-white bg-black rounded bottom-2 right-2 bg-opacity-70"
				>
					{formatDuration(videoInfo.data.duration)}
				</div>
			</div>
		{:else}
			<div class="aspect-video">
				<iframe
					src={videoInfo.data.embed.iframe_url}
					title={videoInfo.data.title}
					allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
					allowfullscreen
					class="w-full h-full"
				></iframe>
			</div>
		{/if}

		<div class="p-4">
			<h3 class="mb-2 text-xl font-semibold">{videoInfo.data.title}</h3>
			<div class="flex items-center mb-3">
				<p class="text-surface-600-300-token">
					By {videoInfo.data.author}
				</p>
				<!-- <span class="mx-2 text-surface-600-300-token">•</span>
				<p class="text-surface-600-300-token">
					{videoInfo.data.view_count?.toLocaleString()
						? videoInfo.data.view_count?.toLocaleString()
						: '-'} views
				</p> -->
			</div>

			{#if videoInfo.data.keywords && videoInfo.data.keywords.length > 0}
				<div class="flex flex-wrap gap-2 mt-3">
					{#each videoInfo.data.keywords.slice(0, 5) as keyword}
						<span class="badge variant-soft-primary">{keyword}</span>
					{/each}
				</div>
			{/if}
		</div>
	</div>
{/if}
