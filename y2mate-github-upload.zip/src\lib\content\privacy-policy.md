# Privacy Policy

## Last Updated: March 14, 2025

Welcome to Y2Mate ("we," "our," or "us"). We respect your privacy and are committed to protecting your personal information. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website and use our YouTube to MP3 conversion service.

Please read this Privacy Policy carefully. By accessing or using our service, you acknowledge that you have read and understood this Privacy Policy.

## Information We Collect

### Information You Provide to Us

We do not require you to create an account or provide personal information to use our service. However, when you use our website, we may collect:

- **YouTube URLs or search queries** that you enter into our search box
- **Browser type and settings** necessary for proper functionality
- **IP address** for security and service optimization purposes

### Information Collected Automatically

When you visit Y2Mate, our servers automatically collect:

- **Log data** including your IP address, browser type, referring/exit pages, operating system, date/time stamps, and clickstream data
- **Device information** including device type, operating system, and browser information
- **Usage data** regarding your interaction with our website

### Cookies and Similar Technologies

We use cookies and similar tracking technologies to enhance your browsing experience and analyze website traffic. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent.

## How We Use Your Information

We use the information we collect to:

- Provide, maintain, and improve our services
- Monitor and analyze usage and trends
- Detect, prevent, and address technical issues
- Improve the safety and security of our service
- Comply with legal obligations

## Data Security

We implement appropriate technical and organizational security measures to protect your information. However, please be aware that no method of transmission over the Internet or method of electronic storage is 100% secure.

## Third-Party Services

Our service may contain links to third-party websites, services, or advertisements. We are not responsible for the privacy practices or content of these third-party sites.

### YouTube API Services

Our service uses YouTube API Services to search for and retrieve video information. By using our service, you are also bound by [Google's Privacy Policy](https://policies.google.com/privacy).

## Children's Privacy

Our service is not directed to children under 13. We do not knowingly collect personal information from children under 13. If you are a parent or guardian and believe your child has provided us with personal information, please contact us.

## International Data Transfers

Your information may be transferred to and processed in countries other than the country in which you reside. These countries may have data protection laws that are different from the laws of your country.

## Changes to This Privacy Policy

We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date.

## Your Rights

Depending on your location, you may have rights concerning your personal information, such as:

- The right to access information we have about you
- The right to request that we delete your information
- The right to object to processing of your information
- The right to restrict processing of your information
- The right to data portability

## Legal Basis for Processing

We process your information based on:

- Your consent
- Our legitimate interests in providing and improving our services
- Compliance with legal obligations

## Contact Us

If you have any questions about this Privacy Policy, please contact us at:

**Email:** privacy@y2mate.com

**Postal Address:**  
Y2Mate Privacy Team  
123 Web Street  
Tech City, TC 12345  
United States