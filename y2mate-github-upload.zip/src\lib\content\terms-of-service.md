# Terms of Service

## Last Updated: March 14, 2025

Welcome to Y2Mate. These Terms of Service ("Terms") govern your access to and use of the Y2Mate website and YouTube to MP3 conversion services ("Service"). By accessing or using our Service, you agree to be bound by these Terms.

## 1. Acceptance of Terms

By accessing or using our Service, you confirm that you accept these Terms and agree to comply with them. If you do not agree with these Terms, you must not access or use our Service.

## 2. Changes to Terms

We may revise these Terms at any time by updating this page. By continuing to use our Service after those revisions become effective, you agree to be bound by the revised Terms.

## 3. Service Description

Y2Mate provides a free online service that allows users to convert YouTube videos to audio formats such as MP3, M4A, and FLAC, and to download videos in various resolutions including 4K, 2K, 1080p, 720p, 480p, and 360p.

## 4. User Responsibilities

### 4.1 Legal Use

You agree to use our Service only for lawful purposes and in accordance with these Terms. You agree not to use our Service:

- In any way that violates any applicable federal, state, local, or international law or regulation
- For the purpose of exploiting, harming, or attempting to exploit or harm minors in any way
- To infringe upon or violate our intellectual property rights or the intellectual property rights of others
- To transmit any material that is defamatory, obscene, invasive of another's privacy, or otherwise objectionable

### 4.2 Copyright and Intellectual Property

Our Service should only be used to convert and download content:

- That you have created yourself
- That is in the public domain
- That you have authorization or permission to download
- Where your use constitutes fair use or is otherwise legally permitted

Y2Mate respects the intellectual property rights of others. We do not claim ownership of any content that is accessed through our Service. You are solely responsible for ensuring that your use of our Service complies with applicable copyright and other laws.

## 5. Service Availability and Modifications

We strive to ensure that our Service is available at all times. However, we do not guarantee that our Service will be available at all times and without interruption. We reserve the right to modify, suspend, or discontinue our Service, temporarily or permanently, with or without notice, at any time.

## 6. No Warranties

Our Service is provided on an "as is" and "as available" basis. Y2Mate makes no warranties, expressed or implied, and hereby disclaims all warranties, including without limitation:

- The Service will meet your specific requirements
- The Service will be uninterrupted, timely, secure, or error-free
- The results that may be obtained from the use of the Service will be accurate or reliable
- Any errors in the Service will be corrected

## 7. Limitation of Liability

In no event shall Y2Mate, its directors, employees, partners, agents, suppliers, or affiliates be liable for any indirect, incidental, special, consequential, or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from:

- Your access to or use of or inability to access or use our Service
- Any conduct or content of any third party on our Service
- Any content obtained from our Service
- Unauthorized access, use, or alteration of your transmissions or content

## 8. Indemnification

You agree to defend, indemnify, and hold harmless Y2Mate and its licensees and licensors, and their employees, contractors, agents, officers, and directors, from and against any and all claims, damages, obligations, losses, liabilities, costs or debt, and expenses (including but not limited to attorney's fees) arising from:

- Your use of and access to our Service
- Your violation of any term of these Terms
- Your violation of any third-party right, including without limitation any copyright, property, or privacy right

## 9. Third-Party Services

Our Service may contain links to third-party websites or services that are not owned or controlled by Y2Mate. We have no control over, and assume no responsibility for, the content, privacy policies, or practices of any third-party websites or services.

## 10. Termination

We may terminate or suspend your access to our Service immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach these Terms.

## 11. Governing Law

These Terms shall be governed and construed in accordance with the laws of the United States, without regard to its conflict of law provisions.

## 12. Contact Us

If you have any questions about these Terms, please contact us at:

**Email:** terms@y2mate.com

**Postal Address:**  
Y2Mate Legal Team  
123 Web Street  
Tech City, TC 12345  
United States