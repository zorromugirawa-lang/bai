<!-- src/routes/+error.svelte -->
<script>
    import { page } from '$app/stores';
    
    // Get the current status code from the page store
    $: status = $page.status;
    $: is404 = status === 404;
  </script>
  
  {#if is404}
    <div class="error-container">
      <div class="error-code">404</div>
      <h1>Page Not Found</h1>
      <p>We couldn't find the page you were looking for.</p>
      <a href="/" class="home-button">Back to Home</a>
    </div>
  {:else}
    <div class="error-container">
      <div class="error-code">{status}</div>
      <h1>Something went wrong</h1>
      <p>{$page.error?.message || 'An unexpected error occurred'}</p>
      <a href="/" class="home-button">Back to Home</a>
    </div>
  {/if}
  
  <style>
    .error-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      padding: 2rem;
      background-color: #f8f9fa;
      text-align: center;
    }
  
    .error-code {
      font-size: 10rem;
      font-weight: 700;
      color: #e74c3c;
      line-height: 1;
      margin-bottom: 1rem;
      text-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
  
    h1 {
      font-size: 2.5rem;
      color: #2c3e50;
      margin-bottom: 1rem;
    }
  
    p {
      font-size: 1.25rem;
      color: #7f8c8d;
      max-width: 600px;
      margin-bottom: 2rem;
    }
  
    .home-button {
      display: inline-block;
      padding: 0.75rem 1.5rem;
      background-color: #3498db;
      color: white;
      text-decoration: none;
      border-radius: 4px;
      font-weight: 600;
      transition: background-color 0.2s, transform 0.1s;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
  
    .home-button:hover {
      background-color: #2980b9;
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
    }
  
    .home-button:active {
      transform: translateY(0);
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
  </style>