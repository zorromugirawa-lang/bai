import { redirect } from '@sveltejs/kit';
import { defaultLanguage } from '$lib/i18n/translations';

export const load = ({ url }) => {
  // Redirect root path to default language
  if (url.pathname === '/') {
    throw redirect(307, `/${defaultLanguage}`);
  }
};