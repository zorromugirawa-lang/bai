import { supportedLanguages, defaultLanguage, translations } from '$lib/i18n/translations';
import { redirect } from '@sveltejs/kit';
import { error } from '@sveltejs/kit';

export const load = ({ params }) => {
  const { lang } = params;
  
  // Check if the requested language is supported
  if (!supportedLanguages.includes(lang)) {
    error(404, {
			message: 'Not found'
		});
  }
  
  return {
    lang,
    translations: translations[lang]
  };
};