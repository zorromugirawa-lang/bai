<script>
  import '@fortawesome/fontawesome-free/css/all.min.css';
  import '../../app.postcss';
  import { AppShell, AppBar, LightSwitch } from '@skeletonlabs/skeleton';
  import { page } from '$app/stores';
  import { supportedLanguages } from '$lib/i18n/translations';
  import { onMount } from 'svelte';
  
  export let data;
  const t = data.translations;
  
  // Set the HTML language attribute to match the current language
  $: lang = t.meta.language || data.lang;
  
  // For the dropdown
  let dropdownOpen = false;
  
  // Toggle dropdown
  function toggleDropdown() {
    dropdownOpen = !dropdownOpen;
  }
  
  // Close dropdown when clicking outside
  function handleClickOutside(event) {
    const dropdown = document.getElementById('language-dropdown');
    if (dropdown && !dropdown.contains(event.target)) {
      dropdownOpen = false;
    }
  }
  
  // Flag mapping for languages - add more as needed
  const flagMap = {
    'id': '🇮🇩', // Indonesian
    'en': '🇺🇸', // English (US)
    'vi': '🇻🇳', // Vietnam
    'es': '🇪🇸', // Spanish
    'fr': '🇫🇷', // French
    'de': '🇩🇪', // German
    'it': '🇮🇹', // Italian
    'pt': '🇵🇹', // Portuguese
    'ru': '🇷🇺', // Russian
    'zh': '🇨🇳', // Chinese
    'ja': '🇯🇵', // Japanese
    'ko': '🇰🇷', // Korean
    'ar': '🇸🇦', // Korean
    'my': '🇲🇲', // myanmar
    'tl': '🇵🇭', // Filipino
    'bn': '🇧🇩', // Bengali
    'so': '🇸🇴', // Somali
    'th': '🇹🇭', // Thai
    'hi': '🇮🇳', // Hindi
    'tr': '🇹🇷', // Turkish
    'af': '🇿🇦', // Afrikaans
    // Add more languages as needed
  };
  
  // Get flag for a language code, fallback to empty string if not found
  function getFlag(langCode) {
    return flagMap[langCode] || '';
  }
  
  // Add event listener when component mounts and set HTML lang attribute
  onMount(() => {
    document.addEventListener('click', handleClickOutside);
    document.documentElement.setAttribute('lang', lang);
    
    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  });
</script>

<!-- Ensure the HTML lang attribute stays in sync with language changes -->
<svelte:head>
  {@html `<script>document.documentElement.lang = "${lang}"</script>`}
</svelte:head>

<AppShell>
  <svelte:fragment slot="header">
    <AppBar class="px-4 sm:px-8">
      <svelte:fragment slot="lead">
        <a href="/{data.lang}" data-sveltekit-reload class="flex items-center">
          <i class="mr-2 text-2xl fa-solid fa-headphones-simple text-primary-500"></i>
          <strong class="hidden text-xl sm:block">Y2Mate</strong>
        </a>
      </svelte:fragment>
      <svelte:fragment slot="trail">
        <div class="flex items-center gap-4">
          <a href="/blog" data-sveltekit-reload class="btn btn-sm variant-soft-surface">
            <i class="fa-solid fa-blog mr-2"></i>
            {t.nav?.blog || 'Blog'}
          </a>
          <div class="relative" id="language-dropdown">
            <button 
              class="flex items-center gap-2 btn btn-sm variant-soft-surface" 
              on:click|stopPropagation={toggleDropdown}
            >
              <span class="mr-1">{getFlag(data.lang)}</span>
              <span>{data.lang.toUpperCase()}</span>
              <i class="text-xs fa-solid fa-chevron-down"></i>
            </button>
            
            {#if dropdownOpen}
              <div class="absolute right-0 z-50 p-1 mt-1 overflow-y-auto shadow-lg card w-28 max-h-48">
                <ul class="list">
                  {#each supportedLanguages as lang}
                    <li>
                      <a 
                        data-sveltekit-reload
                        href="/{lang}{$page.url.search}" 
                        class="btn btn-sm {data.lang === lang ? 'variant-filled-primary' : 'variant-soft'} w-full justify-start"
                      >
                        <span class="mr-2">{getFlag(lang)}</span>
                        <span>{lang.toUpperCase()}</span>
                      </a>
                    </li>
                  {/each}
                </ul>
              </div>
            {/if}
          </div>
          <LightSwitch />
        </div>
      </svelte:fragment>
    </AppBar>
  </svelte:fragment>
  
  <main class="container px-4 py-8 mx-auto">
    <slot />
  </main>
  
  <div class="container flex flex-col justify-between gap-4 p-4 pt-6 mx-auto mt-4 border-t border-surface-300-600-token sm:flex-row">
    <div>
      <p class="text-sm text-surface-600-300-token">{t.footer.copyright}</p>
      <p class="mt-1 text-xs text-surface-600-300-token">{t.footer.tagline}</p>
    </div>
    <div class="flex items-center gap-4">
      <a href="/privacy" data-sveltekit-reload class="btn btn-sm variant-ghost-surface">{t.footer.privacy}</a>
      <a href="/terms" data-sveltekit-reload class="btn btn-sm variant-ghost-surface">{t.footer.terms}</a>
      <div class="flex gap-3">
        <a href="/contact" data-sveltekit-reload class="text-surface-600-300-token hover:text-primary-500">
          <i class="fa-solid fa-envelope"></i>
        </a>
        <a href="https://x.com/y2mateOne" class="text-surface-600-300-token hover:text-primary-500">
          <i class="fa-brands fa-twitter"></i>
        </a>
      </div>
    </div>
    {#if t.footer.disclaimer}
      <div class="w-full mt-4 text-xs text-center text-surface-600-300-token">
        <p>{t.footer.disclaimer}</p>
      </div>
    {/if}
  </div>
</AppShell>