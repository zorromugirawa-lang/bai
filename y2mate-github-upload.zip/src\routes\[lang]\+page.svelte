<script>
	import { PUBLIC_BASE_URL } from '$env/static/public';

	import { fade, fly } from 'svelte/transition';
	import { onMount } from 'svelte';
	import { slide } from 'svelte/transition';

	import { browser } from '$app/environment';
	import { page } from '$app/stores';
	import { fetchVideoInfo, searchVideos, extractVideoId } from '$lib/utils/api.js';
	import SearchBar from '$lib/components/SearchBar.svelte';
	import ResultCard from '$lib/components/ResultCard.svelte';
	import SearchResults from '$lib/components/SearchResults.svelte';
	import FeaturedSection from '$lib/components/FeaturedSection.svelte';
	import { supportedLanguages } from '$lib/i18n/translations';
	import AdvantagesSection from '../../lib/components/AdvantagesSection.svelte';

	// Get translations from data passed from layout
	export let data;
	const t = data.translations;
	let openFaqs = [];

	let videoInfo = null;
	let isLoading = false;
	let error = null;
	let recentConversionsComponent;

	// Search state
	let searchResults = { items: [], nextPage: null };
	let isSearching = false;
	let searchQuery = '';
	let showSearchResults = false;

	async function handleSearch(event) {
		const { videoId, callback } = event.detail;

		// Clear search results when converting a direct URL
		showSearchResults = false;
		searchResults = { items: [], nextPage: null };

		await fetchVideoData(videoId);

		// Call the callback to reset loading state in SearchBar
		if (callback && typeof callback === 'function') {
			callback();
		}
	}

	function toggleFaq(index) {
		openFaqs = openFaqs.map((state, i) => (i === index ? !state : state));

		// Uncomment below for exclusive accordion (only one open at a time)
		// openFaqs = openFaqs.map((state, i) => i === index ? !state : false);
	}

	async function handleTextSearch(event) {
		const { query, callback } = event.detail;

		if (!query.trim()) {
			if (callback && typeof callback === 'function') {
				callback();
			}
			return;
		}

		searchQuery = query;
		showSearchResults = true;
		videoInfo = null; // Clear video info when searching

		await performSearch(query);

		// Call the callback to reset loading state in SearchBar
		if (callback && typeof callback === 'function') {
			callback();
		}
	}

	async function handleVideoSelect(event) {
		const { videoId } = event.detail;
		await fetchVideoData(videoId);
		showSearchResults = false; // Hide search results after selecting a video
	}

	async function loadMoreResults() {
		if (!searchResults.nextPage) return;

		await performSearch(searchQuery, searchResults.nextPage.nextPageToken);
	}

	async function performSearch(query, nextPageToken = '') {
		if (!browser || !query) return;

		try {
			isSearching = true;
			error = null;

			const results = await searchVideos(query, nextPageToken);

			if (nextPageToken) {
				// Append to existing results
				searchResults = {
					items: [...searchResults.items, ...results.items],
					nextPage: results.nextPage
				};
			} else {
				// New search
				searchResults = results;
			}
		} catch (err) {
			error = t.search.searchErrorText;
			console.error(err);
		} finally {
			isSearching = false;
		}
	}

	async function fetchVideoData(videoId) {
		if (!videoId || !browser) return;

		try {
			isLoading = true;
			error = null;
			videoInfo = null;

			// Update URL without reloading page
			const url = new URL(window.location);
			// url.searchParams.set('v', videoId);
			window.history.pushState({}, '', url);

			const result = await fetchVideoInfo(videoId);
			videoInfo = result;

			// Add to recent conversions
			if (recentConversionsComponent && result.status === 200) {
				recentConversionsComponent.addConversion(result);
			}
		} catch (err) {
			error = t.search.errorText;
			console.error(err);
		} finally {
			isLoading = false;
		}
	}

	onMount(() => {
		if (!browser) return;

		// Check if there's a video ID in the URL
		const urlParams = new URLSearchParams(window.location.search);
		// const videoId = urlParams.get('v');
		const videoId = null;
		// const q = urlParams.get('q');
		const q = null;

		if (videoId) {
			fetchVideoData(videoId);
		} else if (q) {
			searchQuery = q;
			showSearchResults = true;
			performSearch(q);
		}

		if (t.faq && t.faq.questions) {
			openFaqs = Array(t.faq.questions.length).fill(false);
			// Optionally open the first FAQ by default
			// openFaqs[0] = true;
		}

		// Handle browser back/forward navigation
		window.addEventListener('popstate', () => {
			const urlParams = new URLSearchParams(window.location.search);
			// const videoId = urlParams.get('v');
			const videoId = null;
			// const q = urlParams.get('q');
			const q = null;

			if (videoId) {
				fetchVideoData(videoId);
				showSearchResults = false;
			} else if (q) {
				searchQuery = q;
				showSearchResults = true;
				performSearch(q);
				videoInfo = null;
			} else {
				// Clear all data if no ID in URL
				videoInfo = null;
				error = null;
				showSearchResults = false;
				searchResults = { items: [], nextPage: null };
			}
		});
	});
</script>

<!-- +page.svelte file with enhanced SEO -->
<svelte:head>
	<title>{t.meta.title}</title>
	<meta name="description" content={t.meta.description} />
	<meta name="keywords" content={t.meta.keywords} />
	<meta name="language" content={t.meta.language} />

	<!-- Canonical URL -->
	<link rel="canonical" href={t.meta.canonical || `https://y2mate.com/${data.lang}`} />

	<!-- Open Graph Meta Tags -->
	<meta property="og:title" content={t.meta.ogTitle || t.meta.title} />
	<meta property="og:description" content={t.meta.ogDescription || t.meta.description} />
	<meta property="og:image" content={t.meta.ogImage || 'https://y2mate.com/images/og-image.jpg'} />
	<meta property="og:url" content={t.meta.canonical || `https://y2mate.com/${data.lang}`} />
	<meta property="og:type" content="website" />
	<meta property="og:site_name" content="Y2Mate" />

	<!-- Twitter Card Meta Tags -->
	<meta name="twitter:card" content={t.meta.twitterCard || 'summary_large_image'} />
	<meta name="twitter:title" content={t.meta.twitterTitle || t.meta.title} />
	<meta name="twitter:description" content={t.meta.twitterDescription || t.meta.description} />
	<meta
		name="twitter:image"
		content={t.meta.twitterImage || t.meta.ogImage || 'https://y2mate.com/images/og-image.jpg'}
	/>

	<!-- Structured Data for Rich Results -->
	{@html `<script type="application/ld+json">
    ${JSON.stringify({
      "@context": "https://schema.org",
      "@type": "WebApplication",
      "name": "Y2Mate YouTube to MP3 Converter",
      "url": t.meta.canonical || `${PUBLIC_BASE_URL}/${data.lang}`,
      "description": t.meta.description,
      "applicationCategory": "MultimediaApplication",
      "operatingSystem": "Any",
      "offers": {
        "@type": "Offer",
        "price": "0",
        "priceCurrency": "USD"
      }
    })}
	</script>`}

	<!-- Alternate language versions -->
	{#each supportedLanguages as lang}
		<link rel="alternate" hreflang={lang} href={`${PUBLIC_BASE_URL}/${lang}`} />
	{/each}
	<link rel="alternate" hreflang="x-default" href={`${PUBLIC_BASE_URL}/en`} />
</svelte:head>

<div class="flex flex-col items-center justify-center min-h-[35vh] mb-6">
	<div in:fly={{ y: -20, duration: 600 }} out:fade class="mb-8 text-center">
		<h1 class="mb-4 text-3xl font-bold md:text-3xl gradient-heading">
			{t.header.title}
		</h1>

		<!-- <div class="flex justify-center mt-4 space-x-2">
      {#each supportedLanguages as lang}
        <a 
          href="/{lang}{$page.url.search}" 
          class="px-2 py-1 text-sm rounded {data.lang === lang ? 'bg-primary-500 text-white' : 'bg-surface-200-700-token text-surface-900-50-token hover:bg-primary-300'}"
        >
          {lang.toUpperCase()}
        </a>
      {/each}
    </div> -->
	</div>

	<div class="w-full max-w-4xl">
		<SearchBar
			on:search={handleSearch}
			on:textSearch={handleTextSearch}
			placeholder={t.search.placeholder}
			buttonText={t.search.button}
		/>
	</div>
</div>

<div class="container px-1 mx-auto mb-8">
	{#if isLoading}
		<div class="flex flex-col items-center mt-8" in:fade>
			<div class="w-16 h-16 spinner">
				<i class="text-4xl fa-solid fa-circle-notch animate-spin text-primary-500"></i>
			</div>
			<p class="mt-4 text-surface-600-300-token">{t.search.loadingText}</p>
		</div>
	{:else if error}
		<div class="mt-8 alert variant-filled-error" in:fly={{ y: 20, duration: 300 }}>
			<i class="mr-2 fa-solid fa-triangle-exclamation"></i>
			{error}
		</div>
	{:else if showSearchResults}
		<div class="mt-8">
			<SearchResults
				{searchResults}
				isLoading={isSearching}
				query={searchQuery}
				on:selectVideo={handleVideoSelect}
				on:loadMore={loadMoreResults}
				translations={t}
			/>
		</div>
	{:else if videoInfo}
		<div class="w-full max-w-xl mx-auto mt-8" in:fly={{ y: 20, duration: 300 }}>
			<ResultCard {videoInfo} translations={t.results} />
		</div>
	{/if}
</div>

<div class="container mb-8">
	<p class="max-w-2xl mx-auto text-lg text-center text-surface-600-300-token">
		{t.header.subtitle}
	</p>
</div>

{#if !videoInfo && !showSearchResults}
	<AdvantagesSection translations={t.advantages} />

	<FeaturedSection translations={t.featured} />

	<section class="container max-w-3xl px-1 mx-auto my-12">
		<h2 class="mb-6 text-2xl font-bold text-center">{t.howTo.title}</h2>

		<div class="p-6 bg-white card rounded-lg dark:bg-surface-800">
			<ol class="pl-6 space-y-4 list-decimal">
				{#each t.howTo.steps as step, i}
					<li class="p-2">
						<h3 class="font-semibold">{step.title}</h3>
						<p class="text-surface-600-300-token">{step.description}</p>
					</li>
				{/each}
			</ol>
		</div>
	</section>

	<section class="container px-4 mx-auto my-12">
		<h2 class="mb-6 text-2xl font-bold text-center">{t.faq.title}</h2>

		<div class="max-w-4xl mx-auto">
			{#each t.faq.questions as faq, index}
				<div class="mb-2 overflow-hidden rounded-2xl bg-white card dark:bg-surface-800">
					<!-- Accordion header -->
					<button
						class="flex items-center justify-between w-full p-4 text-left transition-colors hover:bg-surface-100 dark:hover:bg-surface-700"
						on:click={() => toggleFaq(index)}
						aria-expanded={openFaqs[index]}
						aria-controls={`faq-content-${index}`}
					>
						<h3 class="font-semibold">{faq.question}</h3>
						<i
							class="fa-solid {openFaqs[index]
								? 'fa-chevron-up'
								: 'fa-chevron-down'} transition-transform"
						></i>
					</button>

					<!-- Accordion content -->
					{#if openFaqs[index]}
						<div
							id={`faq-content-${index}`}
							class="p-4 border-t border-surface-200 dark:border-surface-700"
							transition:slide={{ duration: 300 }}
						>
							<p class="text-surface-600-300-token">{faq.answer}</p>
						</div>
					{/if}
				</div>
			{/each}
		</div>
	</section>

	<section class="container max-w-3xl px-4 mx-auto my-12">
		<h2 class="mb-6 text-2xl font-bold text-center">{t.additionalContent.title}</h2>
		<div class="p-6 bg-white rounded-lg card dark:bg-surface-800">
			{#each t.additionalContent.paragraphs as paragraph}
				<p class="mb-4 text-surface-600-300-token">{paragraph}</p>
			{/each}
		</div>
	</section>
{/if}

<style>
	.spinner {
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.gradient-heading {
		background-size: 150% auto;
		animation: gradient 5s ease infinite;
	}

	@keyframes gradient {
		0% {
			background-position: 0% 50%;
		}
		50% {
			background-position: 100% 50%;
		}
		100% {
			background-position: 0% 50%;
		}
	}
</style>
