import { supportedLanguages, defaultLanguage, translations } from '$lib/i18n/translations';
import { redirect } from '@sveltejs/kit';

export const load = ({ params }) => {
  const { lang } = params;
  
  return {
    lang,
    translations: translations['en']
  };
};