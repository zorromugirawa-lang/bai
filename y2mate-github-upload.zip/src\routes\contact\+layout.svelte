<script>
    import '@fortawesome/fontawesome-free/css/all.min.css';

  import '../../app.postcss';
  import { AppShell, AppBar, LightSwitch } from '@skeletonlabs/skeleton';
  export let data;
  const t = data.translations;
  
  // Set the HTML language attribute to match the current language
  
</script>


<AppShell>
  <svelte:fragment slot="header">
    <AppBar class="px-4 sm:px-8">
      <svelte:fragment slot="lead">
        <a href="/" class="flex items-center">
          <i class="mr-2 text-2xl fa-solid fa-headphones-simple text-primary-500"></i>
          <strong class="hidden text-xl sm:block">Y2Mate</strong>
        </a>
      </svelte:fragment>
      <svelte:fragment slot="trail">
				<div class="flex items-center gap-4">
					<LightSwitch />
				</div>
			</svelte:fragment>
    </AppBar>
  </svelte:fragment>
  
  <main class="container px-4 py-8 mx-auto">
    <slot />
  </main>

  <div class="container flex flex-col justify-between gap-4 p-4 pt-6 mx-auto mt-4 border-t border-surface-300-600-token sm:flex-row">
    <div>
      <p class="text-sm text-surface-600-300-token">{t.footer.copyright}</p>
      <p class="mt-1 text-xs text-surface-600-300-token">{t.footer.tagline}</p>
    </div>
    <div class="flex items-center gap-4">
      <a href="/privacy" data-sveltekit-reload class="btn btn-sm variant-ghost-surface">{t.footer.privacy}</a>
      <a href="/terms" data-sveltekit-reload class="btn btn-sm variant-ghost-surface">{t.footer.terms}</a>
      <div class="flex gap-3">
        <a href="/contact" data-sveltekit-reload class="text-surface-600-300-token hover:text-primary-500">
          <i class="fa-solid fa-envelope"></i>
        </a>
        <a href="https://x.com/y2mateOne" class="text-surface-600-300-token hover:text-primary-500">
          <i class="fa-brands fa-twitter"></i>
        </a>
      </div>
    </div>
    {#if t.footer.disclaimer}
      <div class="w-full mt-4 text-xs text-center text-surface-600-300-token">
        <p>{t.footer.disclaimer}</p>
      </div>
    {/if}
  </div>
</AppShell>