// This file is needed to make the dynamic [lang] route work with SvelteKit
export function load() {
    return {};
  }