<script>
  import { fly, fade } from 'svelte/transition';
</script>

<svelte:head>
  <title>Contact Us | Y2Mate</title>
  <meta name="description" content="Get in touch with the Y2Mate team. We'd love to hear from you about our YouTube to MP3 converter service.">
</svelte:head>

<div class="container mx-auto px-4 py-8">
  <!-- Hero Section -->
  <div class="text-center mb-12" in:fly={{ y: -20, duration: 600 }} out:fade>
    <h1 class="text-4xl md:text-5xl font-bold mb-4 text-primary-500">Contact Us</h1>
    <p class="text-lg max-w-2xl mx-auto">
      Have questions, suggestions, or need assistance? We'd love to hear from you!
    </p>
  </div>
  
  <!-- Contact Information -->
  <div class="max-w-3xl mx-auto mb-16">
    <div class="card p-8 text-center variant-ringed">
      <div class="mb-6 text-primary-500 text-5xl">
        <i class="fa-solid fa-envelope-open-text"></i>
      </div>
      
      <h2 class="text-2xl font-bold mb-3">Email Us</h2>
      <p class="text-lg mb-6">
        <a href="mailto:support@y2mate.com" class="text-primary-500 hover:underline">
          support@y2mate.com
        </a>
      </p>
      
      <p class="text-surface-700-200-token mb-6">
        We typically respond to all inquiries within 24-48 hours during business days.
      </p>
      
      <div class="pt-4 border-t border-surface-300-600-token">
        <h3 class="font-medium mb-3">Connect With Us</h3>
        <div class="flex justify-center space-x-6">
          <a href="#" class="btn-icon btn-icon-sm variant-soft hover:variant-filled-primary">
            <i class="fa-brands fa-twitter"></i>
          </a>
          <a href="#" class="btn-icon btn-icon-sm variant-soft hover:variant-filled-primary">
            <i class="fa-brands fa-facebook"></i>
          </a>
          <a href="#" class="btn-icon btn-icon-sm variant-soft hover:variant-filled-primary">
            <i class="fa-brands fa-github"></i>
          </a>
        </div>
      </div>
    </div>
  </div>
  
  <!-- FAQ Section -->
  <div>
    <h2 class="text-2xl font-bold mb-8 text-center">Frequently Asked Questions</h2>
    
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto mb-12">
      <div class="card p-6 variant-soft relative rounded-lg group hover:shadow-xl transition-all duration-200">
        <div class="absolute -top-5 left-1/2 transform -translate-x-1/2 w-10 h-10 rounded-full flex items-center justify-center bg-primary-500 text-white">
          <i class="fa-solid fa-clock"></i>
        </div>
        <h3 class="font-semibold mb-2 pt-4 text-center">Response Time</h3>
        <p class="text-surface-700-200-token text-center">
          We aim to respond to all inquiries within 24-48 hours during business days.
        </p>
      </div>
      
      <div class="card p-6 variant-soft relative rounded-lg group hover:shadow-xl transition-all duration-200">
        <div class="absolute -top-5 left-1/2 transform -translate-x-1/2 w-10 h-10 rounded-full flex items-center justify-center bg-primary-500 text-white">
          <i class="fa-solid fa-wrench"></i>
        </div>
        <h3 class="font-semibold mb-2 pt-4 text-center">Technical Issues</h3>
        <p class="text-surface-700-200-token text-center">
          For technical problems, please include the URL, your browser, and device details to help us troubleshoot effectively.
        </p>
      </div>
      
      <div class="card p-6 variant-soft relative rounded-lg group hover:shadow-xl transition-all duration-200">
        <div class="absolute -top-5 left-1/2 transform -translate-x-1/2 w-10 h-10 rounded-full flex items-center justify-center bg-primary-500 text-white">
          <i class="fa-solid fa-lightbulb"></i>
        </div>
        <h3 class="font-semibold mb-2 pt-4 text-center">Feature Requests</h3>
        <p class="text-surface-700-200-token text-center">
          We love hearing your suggestions! Send us an email with features you'd like to see added to Y2Mate.
        </p>
      </div>
    </div>
  </div>
</div>
