<script>
  import { fly, fade } from 'svelte/transition';
  import { Accordion, AccordionItem } from '@skeletonlabs/skeleton';
</script>

<svelte:head>
  <title>Privacy Policy | Y2Mate</title>
  <meta name="description" content="Y2Mate's privacy policy explains how we collect, use, and protect your information when using our YouTube to MP3 converter service.">
  <meta name="robots" content="index">
</svelte:head>

<div class="container px-4 py-8 mx-auto">
  <!-- Hero Section -->
  <div class="mb-12 text-center" in:fly={{ y: -20, duration: 600 }} out:fade>
    <h1 class="mb-4 text-4xl font-bold md:text-5xl text-primary-500">Privacy Policy</h1>
    <p class="">Last Updated: March 14, 2025</p>
  </div>
  
  <!-- Introduction -->
  <div class="max-w-3xl mx-auto mb-8">
    <div class="p-6 mb-6 card dark:bg-surface-800">
      <p class="mb-4">
        Welcome to Y2Mate ("we," "our," or "us"). We respect your privacy and are committed to protecting your personal information. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website and use our YouTube to MP3 conversion service.
      </p>
      
      <p>
        Please read this Privacy Policy carefully. By accessing or using our service, you acknowledge that you have read and understood this Privacy Policy.
      </p>
    </div>
  </div>
  
  <!-- Main Content -->
  <div class="max-w-3xl mx-auto">
    <Accordion class="mb-8" rounded="rounded-lg" collapsible>
      <AccordionItem open>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-circle-info"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">Information We Collect</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4 space-y-4">
            <div>
              <h3 class="mb-2 font-semibold">Information You Provide to Us</h3>
              <p class="mb-2 ">
                We do not require you to create an account or provide personal information to use our service. However, when you use our website, we may collect:
              </p>
              <ul class="pl-6 space-y-1 list-disc">
                <li><strong>YouTube URLs or search queries</strong> that you enter into our search box</li>
                <li><strong>Browser type and settings</strong> necessary for proper functionality</li>
                <li><strong>IP address</strong> for security and service optimization purposes</li>
              </ul>
            </div>
            
            <div>
              <h3 class="mb-2 font-semibold">Information Collected Automatically</h3>
              <p class="mb-2 ">
                When you visit Y2Mate, our servers automatically collect:
              </p>
              <ul class="pl-6 space-y-1 list-disc">
                <li><strong>Log data</strong> including your IP address, browser type, referring/exit pages, operating system, date/time stamps, and clickstream data</li>
                <li><strong>Device information</strong> including device type, operating system, and browser information</li>
                <li><strong>Usage data</strong> regarding your interaction with our website</li>
              </ul>
            </div>
            
            <div>
              <h3 class="mb-2 font-semibold">Cookies and Similar Technologies</h3>
              <p class="">
                We use cookies and similar tracking technologies to enhance your browsing experience and analyze website traffic. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent.
              </p>
            </div>
          </div>
        </svelte:fragment>
      </AccordionItem>
      
      <AccordionItem>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-arrows-spin"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">How We Use Your Information</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4">
            <p class="mb-2 ">We use the information we collect to:</p>
            <ul class="pl-6 space-y-1 list-disc">
              <li>Provide, maintain, and improve our services</li>
              <li>Monitor and analyze usage and trends</li>
              <li>Detect, prevent, and address technical issues</li>
              <li>Improve the safety and security of our service</li>
              <li>Comply with legal obligations</li>
            </ul>
          </div>
        </svelte:fragment>
      </AccordionItem>
      
      <AccordionItem>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-shield-halved"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">Data Security</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4">
            <p class="">
              We implement appropriate technical and organizational security measures to protect your information. However, please be aware that no method of transmission over the Internet or method of electronic storage is 100% secure.
            </p>
          </div>
        </svelte:fragment>
      </AccordionItem>
      
      <AccordionItem>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-arrow-up-right-from-square"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">Third-Party Services</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4 space-y-4">
            <p class="">
              Our service may contain links to third-party websites, services, or advertisements. We are not responsible for the privacy practices or content of these third-party sites.
            </p>
            
            <div>
              <h3 class="mb-2 font-semibold">YouTube API Services</h3>
              <p class="">
                Our service uses YouTube API Services to search for and retrieve video information. By using our service, you are also bound by <a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer" class="text-primary-500 hover:underline">Google's Privacy Policy</a>.
              </p>
            </div>
          </div>
        </svelte:fragment>
      </AccordionItem>
      
      <AccordionItem>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-child"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">Children's Privacy</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4">
            <p class="">
              Our service is not directed to children under 13. We do not knowingly collect personal information from children under 13. If you are a parent or guardian and believe your child has provided us with personal information, please contact us.
            </p>
          </div>
        </svelte:fragment>
      </AccordionItem>
      
      <AccordionItem>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-globe"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">International Data Transfers</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4">
            <p class="">
              Your information may be transferred to and processed in countries other than the country in which you reside. These countries may have data protection laws that are different from the laws of your country.
            </p>
          </div>
        </svelte:fragment>
      </AccordionItem>
      
      <AccordionItem>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-pen-to-square"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">Changes to This Privacy Policy</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4">
            <p class="">
              We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date.
            </p>
          </div>
        </svelte:fragment>
      </AccordionItem>
      
      <AccordionItem>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-user-shield"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">Your Rights</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4">
            <p class="mb-2 ">
              Depending on your location, you may have rights concerning your personal information, such as:
            </p>
            <ul class="pl-6 space-y-1 list-disc">
              <li>The right to access information we have about you</li>
              <li>The right to request that we delete your information</li>
              <li>The right to object to processing of your information</li>
              <li>The right to restrict processing of your information</li>
              <li>The right to data portability</li>
            </ul>
          </div>
        </svelte:fragment>
      </AccordionItem>
      
      <AccordionItem>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-scale-balanced"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">Legal Basis for Processing</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4">
            <p class="mb-2 ">We process your information based on:</p>
            <ul class="pl-6 space-y-1 list-disc">
              <li>Your consent</li>
              <li>Our legitimate interests in providing and improving our services</li>
              <li>Compliance with legal obligations</li>
            </ul>
          </div>
        </svelte:fragment>
      </AccordionItem>
      
      <AccordionItem>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-envelope"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">Contact Us</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4">
            <p class="mb-2 ">
              If you have any questions about this Privacy Policy, please contact us at:
            </p>
            <p>
              <strong>Email:</strong> <a href="mailto:privacy@y2mate.com" class="text-primary-500 hover:underline">privacy@y2mate.com</a>
            </p>
          </div>
        </svelte:fragment>
      </AccordionItem>
    </Accordion>
  </div>
</div>