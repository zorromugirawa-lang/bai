<script>
  import { fly, fade } from 'svelte/transition';
  import { Accordion, AccordionItem } from '@skeletonlabs/skeleton';
</script>

<svelte:head>
  <title>Terms of Service | Y2Mate</title>
  <meta name="description" content="Read the terms and conditions that govern the use of Y2Mate's YouTube to MP3 converter service.">
  <meta name="robots" content="index">
</svelte:head>

<div class="container px-4 py-8 mx-auto">
  <!-- Hero Section -->
  <div class="mb-12 text-center" in:fly={{ y: -20, duration: 600 }} out:fade>
    <h1 class="mb-4 text-4xl font-bold md:text-5xl text-primary-500">Terms of Service</h1>
    <p class="">Last Updated: March 14, 2025</p>
  </div>
  
  <!-- Introduction -->
  <div class="max-w-3xl mx-auto mb-8">
    <div class="card p-6 mb-6">
      <p>
        Welcome to Y2Mate. These Terms of Service ("Terms") govern your access to and use of the Y2Mate website and YouTube to MP3 conversion services ("Service"). By accessing or using our Service, you agree to be bound by these Terms.
      </p>
    </div>
  </div>
  
  <!-- Main Content -->
  <div class="max-w-3xl mx-auto">
    <Accordion class="mb-8" collapsible rounded="rounded-lg">
      <AccordionItem open>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-check-circle"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">1. Acceptance of Terms</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4">
            <p class="">
              By accessing or using our Service, you confirm that you accept these Terms and agree to comply with them. If you do not agree with these Terms, you must not access or use our Service.
            </p>
          </div>
        </svelte:fragment>
      </AccordionItem>
      
      <AccordionItem>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-arrows-rotate"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">2. Changes to Terms</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4">
            <p class="">
              We may revise these Terms at any time by updating this page. By continuing to use our Service after those revisions become effective, you agree to be bound by the revised Terms.
            </p>
          </div>
        </svelte:fragment>
      </AccordionItem>
      
      <AccordionItem>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-circle-info"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">3. Service Description</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4">
            <p class="">
              Y2Mate provides a free online service that allows users to convert YouTube videos to audio formats such as MP3, M4A, and FLAC, and to download videos in various resolutions including 4K, 2K, 1080p, 720p, 480p, and 360p.
            </p>
          </div>
        </svelte:fragment>
      </AccordionItem>
      
      <AccordionItem>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-user-shield"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">4. User Responsibilities</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4 space-y-4">
            <div>
              <h3 class="mb-2 font-semibold">4.1 Legal Use</h3>
              <p class="mb-2 ">
                You agree to use our Service only for lawful purposes and in accordance with these Terms. You agree not to use our Service:
              </p>
              <ul class="pl-6 space-y-1 list-disc">
                <li>In any way that violates any applicable federal, state, local, or international law or regulation</li>
                <li>For the purpose of exploiting, harming, or attempting to exploit or harm minors in any way</li>
                <li>To infringe upon or violate our intellectual property rights or the intellectual property rights of others</li>
                <li>To transmit any material that is defamatory, obscene, invasive of another's privacy, or otherwise objectionable</li>
              </ul>
            </div>
            
            <div>
              <h3 class="mb-2 font-semibold">4.2 Copyright and Intellectual Property</h3>
              <p class="mb-2 ">
                Our Service should only be used to convert and download content:
              </p>
              <ul class="pl-6 space-y-1 list-disc">
                <li>That you have created yourself</li>
                <li>That is in the public domain</li>
                <li>That you have authorization or permission to download</li>
                <li>Where your use constitutes fair use or is otherwise legally permitted</li>
              </ul>
              <p class="mt-2 ">
                Y2Mate respects the intellectual property rights of others. We do not claim ownership of any content that is accessed through our Service. You are solely responsible for ensuring that your use of our Service complies with applicable copyright and other laws.
              </p>
            </div>
          </div>
        </svelte:fragment>
      </AccordionItem>
      
      <AccordionItem>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-server"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">5. Service Availability and Modifications</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4">
            <p class="">
              We strive to ensure that our Service is available at all times. However, we do not guarantee that our Service will be available at all times and without interruption. We reserve the right to modify, suspend, or discontinue our Service, temporarily or permanently, with or without notice, at any time.
            </p>
          </div>
        </svelte:fragment>
      </AccordionItem>
      
      <AccordionItem>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-triangle-exclamation"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">6. No Warranties</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4">
            <p class="mb-2 ">
              Our Service is provided on an "as is" and "as available" basis. Y2Mate makes no warranties, expressed or implied, and hereby disclaims all warranties, including without limitation:
            </p>
            <ul class="pl-6 space-y-1 list-disc">
              <li>The Service will meet your specific requirements</li>
              <li>The Service will be uninterrupted, timely, secure, or error-free</li>
              <li>The results that may be obtained from the use of the Service will be accurate or reliable</li>
              <li>Any errors in the Service will be corrected</li>
            </ul>
          </div>
        </svelte:fragment>
      </AccordionItem>
      
      <AccordionItem>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-scale-balanced"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">7. Limitation of Liability</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4">
            <p class="mb-2 ">
              In no event shall Y2Mate, its directors, employees, partners, agents, suppliers, or affiliates be liable for any indirect, incidental, special, consequential, or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from:
            </p>
            <ul class="pl-6 space-y-1 list-disc">
              <li>Your access to or use of or inability to access or use our Service</li>
              <li>Any conduct or content of any third party on our Service</li>
              <li>Any content obtained from our Service</li>
              <li>Unauthorized access, use, or alteration of your transmissions or content</li>
            </ul>
          </div>
        </svelte:fragment>
      </AccordionItem>

      <AccordionItem>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-shield"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">8. Indemnification</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4">
            <p class="mb-2 ">
              You agree to defend, indemnify, and hold harmless Y2Mate and its licensees and licensors, and their employees, contractors, agents, officers, and directors, from and against any and all claims, damages, obligations, losses, liabilities, costs or debt, and expenses (including but not limited to attorney's fees) arising from:
            </p>
            <ul class="pl-6 space-y-1 list-disc">
              <li>Your use of and access to our Service</li>
              <li>Your violation of any term of these Terms</li>
              <li>Your violation of any third-party right, including without limitation any copyright, property, or privacy right</li>
            </ul>
          </div>
        </svelte:fragment>
      </AccordionItem>
      
      <AccordionItem>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-link"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">9. Third-Party Services</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4">
            <p class="">
              Our Service may contain links to third-party websites or services that are not owned or controlled by Y2Mate. We have no control over, and assume no responsibility for, the content, privacy policies, or practices of any third-party websites or services.
            </p>
          </div>
        </svelte:fragment>
      </AccordionItem>
      
      <AccordionItem>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-ban"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">10. Termination</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4">
            <p class="">
              We may terminate or suspend your access to our Service immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach these Terms.
            </p>
          </div>
        </svelte:fragment>
      </AccordionItem>
      
      <AccordionItem>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-gavel"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">11. Governing Law</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4">
            <p class="">
              These Terms shall be governed and construed in accordance with the laws of the United States, without regard to its conflict of law provisions.
            </p>
          </div>
        </svelte:fragment>
      </AccordionItem>
      
      <AccordionItem>
        <svelte:fragment slot="lead">
          <div class="flex items-center justify-center w-10 h-10 text-white rounded-full bg-primary-700">
            <i class="fa-solid fa-envelope"></i>
          </div>
        </svelte:fragment>
        <svelte:fragment slot="summary">
          <div class="text-lg font-semibold">12. Contact Us</div>
        </svelte:fragment>
        <svelte:fragment slot="content">
          <div class="pl-4 mt-4">
            <p class="mb-2 ">
              If you have any questions about these Terms, please contact us at:
            </p>
            <p>
              <strong>Email:</strong> <a href="mailto:terms@y2mate.com" class="text-primary-500 hover:underline">terms@y2mate.com</a>
            </p>
          </div>
        </svelte:fragment>
      </AccordionItem>
    </Accordion>
  </div>
</div>